Portions © 1982 by Motorola, all rights reserved.

Portions by tim lindner, in the public domain.
