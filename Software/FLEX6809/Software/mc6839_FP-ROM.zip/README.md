C library wrapper for the Motorola MC6839 floating point ROM.
To be used with MC6809 based systems.

Resources:
https://colorcomputerarchive.com/search?q=6839

https://tlindner.macmess.org/?page_id=691

--
tim lindner
tlindner@macmess.org
December 2020
